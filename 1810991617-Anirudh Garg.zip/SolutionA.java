import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;

class Road {
    public String city1;
    public String city2;

    public Road(String city1, String city2) {
        this.city1 = city1;
        this.city2 = city2;
    }
}

class RoadMap {
    Map<String, Set<Road>> roadMap = new HashMap<String, Set<Road>>();
    Map<String, Integer> integerValue = new HashMap<String, Integer>();
    int j = 0;
    //This function helps to get all the cities in the graph
    public Set<String> getAllCities() {
        return this.roadMap.keySet();
    }

    //This function will read the input
    public void readLine(String line) {
        String[] csv = line.split(",");
        String city1 = csv[0];
        String city2 = csv[1];
        addRoad(city1, city2);
    }

    private void addCity(String city) {
        this.roadMap.put(city, new HashSet<Road>());
        this.integerValue.put(city, j++);
    }

    //This function will add both outgoing and incoming roads between two cities
    private void addRoad(String city1, String city2) {
        Road road1 = new Road(city1, city2);
        Road road2 = new Road(city2, city1);
        if (!this.roadMap.containsKey(city1)) {
            addCity(city1);
        }
        if (!this.roadMap.containsKey(city2)) {
            addCity(city2);
        }
        this.roadMap.get(city1).add(road1);
        this.roadMap.get(city2).add(road2);
    }

    //This function will return all the outgoing roads from a city
    public Set<Road> getAllOutgoingRoads(String node) {
        return this.roadMap.get(node);
    }

}

public class Part_A_Stub {
    static RoadMap roadMap = new RoadMap();

    public static void readMap(Scanner scanner) {
        while (true) {
            String mapLine = scanner.nextLine();
            if (mapLine.equals("")) {
                break;
            }
            roadMap.readLine(mapLine);
        }
        System.out.println("Read map");
    }

    public static void findAnyRouteToCity(String source, String destination) {
        int[] visited = new int[roadMap.roadMap.size()]; // distance between two units 1;
        Queue<String> q = new LinkedList<String>();

        Map<String, String> route = new HashMap<String, String>();

        for (int i = 0; i < visited.length; i++) {
            visited[i] = Integer.MAX_VALUE; // default value infinte
        }

        q.add(source); // mumbai
        visited[roadMap.integerValue.get(source)] = 0; // mubai = 0

        while (!q.isEmpty()) {
            String node = q.poll(); // mumbai removed // pune removed
            Set<Road> st = roadMap.roadMap.get(node); // neighbours of mubai // pune // neighbours of pune // mumbai--> indore

            for (Road temp : st) {
                if (visited[roadMap.integerValue.get(temp.city2)] == Integer.MAX_VALUE) {
                    q.add(temp.city2); // q -> pune // q-> indore
                    visited[roadMap.integerValue.get(temp.city2)] = visited[roadMap.integerValue.get(node)] + 1;
                    route.put(temp.city2, node);
                }
            }
        }

        if (visited[roadMap.integerValue.get(destination)] == Integer.MAX_VALUE) {
            System.out.println("Not Reachable");
            return;
        }

        String currentCity = destination;
        String path = destination;
        while (!currentCity.equals(source)) {
            currentCity = route.get(currentCity);
            path = currentCity + " -> " + path;
        }
        System.out.println(path);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Map");
        readMap(scanner);

        System.out.println("Enter the source ");
        String source = scanner.nextLine();
        System.out.println("Enter the destination ");
        String destination = scanner.nextLine();
        System.out.println("The route from "+source+" to "+destination+" is");

        findAnyRouteToCity(source, destination);
    }

}
